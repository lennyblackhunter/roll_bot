#include <iostream>
#include <memory>
#include <vector>
#include <stack>
#include <functional>
#include <sstream>
#include <random>
#include <optional>

#include "tokens.hh"
#include "rpn.hh"
#include "../sort.hh"

/*
 * TO_DO:
 * - add operator class, which keeps information on an operator sign, operation it does and its precedence,
 * - make class node a template - it should take a type of literals
 */

template <typename T>
struct BinaryOperator {
    char operation_symbol;
    std::function<T(T,T)> operation;
    int precedence;
    BinaryOperator() = default;
    BinaryOperator(char operation_symbol, std::function<T(T,T)> operation, int precedence):
            operation_symbol(operation_symbol), operation(operation), precedence(precedence) {};
    BinaryOperator(const BinaryOperator & other):
    operation_symbol(other.operation_symbol), operation(other.operation), precedence(other.precedence) {};
};

int random_number(int x, int y) {
    std::uniform_int_distribution<int> d(x, y);
    std::random_device random_dev;
    int random_number = d(random_dev);
    return random_number;
}

int roll_and_add(int times, int sides) {
    int result = 0;
    for (int i = 0; i < times; i++) {
        result += random_number(1, sides);
    };
    return result;
}

template <typename LiteralType>
class Node {
    using NodePtr = std::unique_ptr<Node>;
    public:
    using NodeType = std::optional<BinaryOperator<LiteralType>>;
    private:
    NodeType node_type;
    LiteralType value;
    NodePtr left, right;
    public:
    explicit Node(LiteralType value) : value(value) {};
    Node(NodeType node_type, NodePtr & left, NodePtr & right) :
     node_type(node_type), left(std::move(left)), right(std::move(right)) {};

    LiteralType evaluate() const {
        if (!node_type) {
            return value;
        }
        else {
            auto left_value = left->evaluate();
            auto right_value = right->evaluate();
            return node_type->operation(left_value, right_value);
        }
    }

    friend
    std::ostream & operator<<(std::ostream & out, const Node & node) {
        if (!node.node_type) {
            out << node.value;
        }
        else {
            if (bracket_condition(node.node_type, node.left -> node_type)) {
                out << "(" << *node.left << ")";
            }
            else {
                out << *node.left;
            }
            out << " " << node.node_type->operation_symbol << " ";
            if (bracket_condition(node.node_type, node.right -> node_type)) {
                out << "(" << *node.right << ")";
            }
            else {
                out << *node.right;
            }
        }
        return out;
    };
};

template <typename T>
bool bracket_condition(const typename Node<T>::NodeType & parent_type, const typename  Node<T>::NodeType & child_type) {
    if (!child_type)
        return false;
    return parent_type->precedence > child_type->precedence;
}


template<typename T>
T extract(std::stack<T> & stack) {
    T top = std::move(stack.top());
    stack.pop();
    return top;
}

template <typename T>
std::optional<T> from_str(const std::string_view & s) {
    std::stringstream ss;
    ss << s;
    std::optional<T> t;
    ss >> *t;
    if (ss.fail()) return std::nullopt;
    return t;
}

template <typename T>
class NodeBuilder {
        std::map<std::string, BinaryOperator<T>> token_types_map;
        std::vector<char> op_symbols;
    public:
        explicit NodeBuilder(const std::vector<BinaryOperator<T>> & ops) {
            for (const auto & op: ops) {
                token_types_map[std::string(1, op.operation_symbol)] = op;
                op_symbols.push_back(op.operation_symbol);
            }
        };

    std::unique_ptr<Node<T>> to_node(const std::vector<Token> & token_list) {
        std::stack<std::unique_ptr<Node<T>>> node_stack;
        for (const Token & token : token_list) {
            if (token.token_type == TOKEN_LITERAL) {
                auto value = from_str<T>(token.value);
                if (!value) return nullptr;
                node_stack.push(std::make_unique<Node<T>> (*value));
            }
            else if (token.token_type == OPERATOR) {
                if (node_stack.size() < 2) {
                    return nullptr;
                }
                auto right = extract(node_stack);
                auto left = extract(node_stack);
                node_stack.push(std::make_unique<Node<T>> (
                        token_types_map[token.value], left, right));
            }
        }
        if (node_stack.size() != 1) {
            return nullptr;
        }
        return extract(node_stack);
    }

    std::unique_ptr<Node<T>> string_to_node(const std::string & str) {
        auto token_list = tokenize(str, op_symbols);
        if (!token_list.has_value()) {
            std::cout << "miau0";
            return nullptr;
        }
        auto rpned = to_rpn(*token_list);
        if (!rpned.has_value()) {
            std::cout << "miau1";
            return nullptr;
        }
        print_vec(*rpned);
        return to_node(*rpned);
    }

};

int main2 {

};


int main1() {
    auto node_builder = NodeBuilder<int>({
                BinaryOperator<int>('k', roll_and_add, 5),
                BinaryOperator<int>('+', [](int x, int y){return x + y;}, 3),
                BinaryOperator<int>('*', [](int x, int y){return x * y;}, 4),
                });
    while (true) {
        std::string line;
        std::getline(std::cin, line);
        auto my_node = node_builder.string_to_node(line);
        if (my_node) {
            std::cout << my_node->evaluate() << std::endl;
        }
        else {
            std::cout << "to nie jest poprawny napis" << std::endl;
        }
    }
};

int main() {
    return main1();
}
